import java.awt.*;
import java.util.*;

import javax.swing.*;

import java.math.*;
class Ball{
	
	int xPosition,yPosition,xSpeed,ySpeed,radius,coefficientOfSpeed,checkCrashBall,colorBall;
	public Ball(){
		xPosition=150;
		yPosition=150;
		xSpeed=1;
		ySpeed=1;
		radius=30;
		coefficientOfSpeed=1;
		checkCrashBall=0;
		colorBall=0;
	}
	public Ball(int xPosition,int yPosition,int radius,int coefficientOfSpeed,int xSpeed,int ySpeed,int checkCrashBall,int colorBall){
		this.xPosition=xPosition;
		this.yPosition=yPosition;
		this.radius=radius;
		this.xSpeed=xSpeed*coefficientOfSpeed;
		this.ySpeed=ySpeed*coefficientOfSpeed;
		this.coefficientOfSpeed=coefficientOfSpeed;
		this.checkCrashBall=checkCrashBall;
		this.colorBall=colorBall;
	}

	public void paint(Graphics graphics){
		
			
		switch(colorBall){
			case 0:
				graphics.setColor(Color.CYAN);
				break;
			case 1:
				graphics.setColor(Color.RED);
				break;
			case 2:
				graphics.setColor(Color.BLACK);
				break;
			case 3:
				graphics.setColor(Color.PINK);
				break;
			case 4:
				graphics.setColor(Color.GREEN);
				break;
		}

//		graphics.setColor(Color.CYAN);
		graphics.fillOval(xPosition+2, yPosition+2, radius*2-4, radius*2-4);
	}
	public void crashWall(int widthDisplay,int heightDisplay){
		if(xPosition>=widthDisplay - 2*radius ){
			xPosition=widthDisplay-2*radius;
            xSpeed=-xSpeed;   
        }
		if(xPosition<=0){
			xPosition=0;
            xSpeed=-xSpeed;
		}
		if(yPosition<=0  ){
			yPosition=0;
			ySpeed=-ySpeed;
     }
		

	}

	public void angleConvertCoordinate(int numberOfAngle,int jumpCoordinate,int coefficientOfSpeed){
		int xSpeedhalf=jumpCoordinate/2+xSpeed-coefficientOfSpeed,xSpeedfull=jumpCoordinate+xSpeed-coefficientOfSpeed;
		int ySpeedhalf=jumpCoordinate/2+ySpeed,ySpeedfull=jumpCoordinate+ySpeed;
		switch(numberOfAngle){
			case 0: 
//			case 0: xSpeed=xSpeedfull;
//					ySpeed=0;
//					break;
			case 1: xSpeed=xSpeedfull;
					ySpeed=ySpeedhalf;
					break;
			case 2: xSpeed=xSpeedfull;
					ySpeed=ySpeedfull;
					break;
			case 3: xSpeed=xSpeedhalf;
					ySpeed=ySpeedfull;
					break;
			case 4:
//			case 4: xSpeed=0;
//					ySpeed=ySpeedfull;
//					break;
			case 5: xSpeed=-xSpeedhalf;
					ySpeed=ySpeedfull;
					break;
			case 6: xSpeed=-xSpeedfull;
					ySpeed=ySpeedfull;	
					break;
			case 7: xSpeed=-xSpeedfull;
					ySpeed=ySpeedhalf;
					break;
			case 8:
//			case 8: xSpeed=-xSpeedfull;
//					ySpeed=0;
//					break;
			case 9: xSpeed=-xSpeedfull;
					ySpeed=-ySpeedhalf;
					break;
			case 10: xSpeed=-xSpeedfull;
					ySpeed=-ySpeedfull;
					 break;
			case 11: xSpeed=-xSpeedhalf;
					ySpeed=-ySpeedfull;
					 break;
			case 12:
//			case 12: xSpeed=0;
//					ySpeed=-ySpeedfull;
//				 	 break;
			case 13: xSpeed=xSpeedhalf;
					ySpeed=-ySpeedfull;
					 break;
			case 14: xSpeed=xSpeedfull;
					ySpeed=-ySpeedfull;
					 break;
			case 15: xSpeed=xSpeedfull;
					ySpeed=-ySpeedhalf;
					 break;
				
		}
	}
	public int crashBall(Ball[] otherBall,int indexOfBall,int numberOfBall){
		int tempX,tempY;
		for(int index=indexOfBall+1;index<numberOfBall;index++){
			double distance2Ball=Math.sqrt(Math.pow(otherBall[index].xPosition-xPosition,2)+Math.pow(otherBall[index].yPosition-yPosition, 2));
			if ( distance2Ball<=(radius+otherBall[index].radius)){
				
				if(xSpeed*otherBall[index].xSpeed<0){
					  if(ySpeed*otherBall[index].ySpeed>=0){
						  xSpeed=-xSpeed;
						  otherBall[index].xSpeed= -otherBall[index].xSpeed;
						  
					  }
					  else{
						  xSpeed=-xSpeed;
						  otherBall[index].xSpeed= -otherBall[index].xSpeed;
						  ySpeed=-ySpeed;
						  otherBall[index].ySpeed= -otherBall[index].ySpeed;
					  }
				  }else{
					  if(ySpeed*otherBall[index].ySpeed>=0){						  
						  tempX=xSpeed;
						  tempY=ySpeed;
						  xSpeed=otherBall[index].xSpeed;
						  ySpeed=otherBall[index].ySpeed;
						  otherBall[index].xSpeed=tempX;
						  otherBall[index].ySpeed=tempY;
						  
					  }else{
						  ySpeed=-ySpeed;
						  otherBall[index].ySpeed= -otherBall[index].ySpeed;
					  }
				  }
				if(Math.round(distance2Ball)<radius+otherBall[index].radius){
					tempX=(otherBall[index].xPosition-xPosition)/20;
					tempY=(otherBall[index].yPosition-yPosition)/20;
					xPosition-=tempX;
					otherBall[index].xPosition+=tempX;
					yPosition-=tempX;
					otherBall[index].yPosition+=tempY;
//					otherBall[index].xPosition-=otherBall[index].xSpeed;
//					otherBall[index].yPosition-=otherBall[index].ySpeed;
					checkCrashBall=1;

				}
				
				  return 1;
			  }		
		}
		return 0;
		
	}
	public int checktoDeleteBall(int height){
		if(yPosition>height+2*radius) return 1;
		return 0;
	}
	public void crashAll(){
		
	}
	public void moveBall(){
		xPosition+=xSpeed;
		yPosition+=ySpeed;
	}
}
