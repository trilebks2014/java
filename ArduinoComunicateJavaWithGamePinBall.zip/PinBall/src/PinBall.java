

import java.util.Enumeration;

import gnu.io.CommPort;
import gnu.io.CommPortIdentifier;
import gnu.io.SerialPort;
import gnu.io.SerialPortEvent;
import gnu.io.SerialPortEventListener;

import javax.swing.*;


import java.awt.event.WindowEvent;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

import java.util.*;
class PinBall extends Frame implements Runnable,MouseListener,KeyListener,MouseMotionListener, SerialPortEventListener  {
	private InputStream    serialIn;
	private OutputStream   serialOut;
	private BufferedReader serialReader;
	int numberOfBall=4,radius=30,numberOfBrick=40,score=0;
	SerialPort serialPort;
	Ball[]  ball = new Ball[numberOfBall];
	Thread ballThread = new Thread(this);
	int widthRect=140,heightRect=10,speedRect=20,countSpeed=0;
	Rectangle rectangle=new Rectangle();
	Brick[] brick = new Brick[numberOfBrick];
	int widthBrick= 35,heightBrick=10;
	public PinBall(){
		setSize(700, 550);
		setVisible(true);
		inputBall();
		inputBrick();
		ballThread.start();
		rectangle=new Rectangle(this.getWidth()/2-widthRect/2,this.getHeight()-heightRect,widthRect,heightRect,speedRect,countSpeed);		
		addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e){
				System.exit(0);
			}
		});
	}
	public void begin() throws Exception{
		this.setVisible(true);
		
		// Open port
		CommPortIdentifier port = CommPortIdentifier.getPortIdentifier("COM5"); 
        CommPort commPort = port.open(this.getClass().getName(),2000);
        serialPort = (SerialPort) commPort;
        serialPort.setSerialPortParams(115200, SerialPort.DATABITS_8, SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);
		serialIn=serialPort.getInputStream();
		serialOut=serialPort.getOutputStream();
		serialReader = new BufferedReader( new InputStreamReader(serialIn) );
        serialPort.addEventListener(this);
        serialPort.notifyOnDataAvailable(true);
        
	}
	public static void main(String[] args) throws Exception{
		
		PinBall pinBall =new PinBall();
		pinBall.begin();
		pinBall.addKeyListener(pinBall);
		
		
//		pinBall.addMouseListener(pinBall);
//		pinBall.addMouseMotionListener(pinBall);
	}

	public void inputBrick(){
		int space=3;
		int line=4,count=0;
		int numberBrickInLine[]={15,10,10,5};
		
		int yPositionBrick=40;
		for(int indexP=0;indexP<line;indexP++){
			
			int xPositionBrick=(this.getWidth()-numberBrickInLine[indexP]*(space+widthBrick))/2;
			for(int index=0;index<numberBrickInLine[indexP];index++){
				brick[count++]=new Brick(xPositionBrick,yPositionBrick,widthBrick,heightBrick);
				xPositionBrick+=widthBrick+space;
			}		
			yPositionBrick+=heightBrick + space;
		}
		
	}
	public void inputBall(){
		int radiusTemp,Speed=3,numberOfAngle,coefficientOfSpeed,jumpCoordinate,checkCrashBall=0,colorBall=0;;
		for(int index=0;index<numberOfBall;index++){
			Random random = new Random();
			numberOfAngle=random.nextInt(16);
			coefficientOfSpeed=random.nextInt(2)+1;
			jumpCoordinate=2;// 2 Pixel devied angle
			System.out.println(index+numberOfAngle);
//			radiusTemp=random.nextInt(5)+radius;
			radiusTemp=30;
			colorBall=random.nextInt(5);
			do{				
				ball[index] = new Ball(random.nextInt(this.getWidth()-3*radius)+2*radius,
				random.nextInt(this.getHeight()-3*radius)+2*radiusTemp,radiusTemp,Speed,Speed,coefficientOfSpeed,checkCrashBall,colorBall);
			}while(ball[index].crashBall(ball, -1, index)==1);
			ball[index].angleConvertCoordinate(numberOfAngle, jumpCoordinate, coefficientOfSpeed);
		}
	}
	public void paint(Graphics graphics){
		for(int index=0;index<numberOfBall;index++){
			ball[index].paint(graphics);
		}
		rectangle.paint(graphics);
		for(int index=0;index<numberOfBrick;index++){
			brick[index].paint(graphics);
		}
	}
	public void deleteBall(int index){
		for(int i=index;i<numberOfBall-1;i++){
			ball[i]=ball[i+1];
		}
		numberOfBall--;
		if(numberOfBall==0){
			JOptionPane.showMessageDialog(null, "GameOver! And have "+score+" score ");
		}
	}
	public void deleteBrick(int index){
		for(int i=index;i<numberOfBrick-1;i++)
			brick[i]=brick[i+1];
		numberOfBrick--;
		if (numberOfBrick==0){
			JOptionPane.showMessageDialog(null, "Win! And have "+score+" score ");
		}
	}
	public void run(){
		while (true){
			try{
				for(int index=0;index<numberOfBall;index++){
					ball[index].checkCrashBall=0;
					ball[index].crashWall(this.getWidth(), this.getHeight());
					ball[index].crashBall(ball,index, numberOfBall);
					rectangle.crashBall(ball[index], this.getHeight());
					for(int j=0;j<numberOfBrick;j++){
						if(brick[j].crashBrick(ball[index])==1){
							score+=10;
							deleteBrick(j);
						}
					}
					if (ball[index].checktoDeleteBall(this.getHeight())==1) deleteBall(index);
					if(ball[index].checkCrashBall==0)ball[index].moveBall();
					
					}
				repaint();
	            Thread.sleep(50);
			}catch(Exception ex){
				System.out.println(ex);
			}
		}
	}

	public void mouseMoved(MouseEvent arg0){
		System.out.println("Moved");
		if((int) arg0.getPoint().getX()<0)rectangle.xPosition=0;
		else if ((int) arg0.getPoint().getX()>this.getWidth()-rectangle.widthRect) rectangle.xPosition=this.getWidth()-rectangle.widthRect;
		else rectangle.xPosition=(int) arg0.getPoint().getX();
	}
	public void mouseDragged(MouseEvent me) {
	    mouseMoved(me);
	    System.out.println("Dragged");
	  }
	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		System.out.println("Clicked");
	}
	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		System.out.println("Entered");
	}
	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		System.out.println("Released");
	}
	@Override
	public void keyPressed(KeyEvent arg0) {
		// TODO Auto-generated method stub

		int location = arg0.getKeyCode();
		if (location==KeyEvent.VK_LEFT){
			rectangle.countSpeedRight=0;
			rectangle.moveLeft();
		}
		if (location==KeyEvent.VK_RIGHT){
			rectangle.countSpeedLeft=0;
			rectangle.moveRight(this.getWidth());
		}
	}
	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void serialEvent(SerialPortEvent arg0) {
		try {
			String line = serialReader.readLine();
//			Log.debug("READ from serial: "+line);
			System.out.println(line);
			if(line.startsWith("SS:") && line.length()==6){
				visualization( line );
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		}	
	}
	private void visualization(String line){
		// Parse the information
		String[] values = line.split(":");
		System.out.println(values[1]);
		System.out.println(values[2]);
		int leftNumber=Integer.parseInt(values[1]);
		int rightNumber=Integer.parseInt(values[2]);
		if(leftNumber==1){
			rectangle.countSpeedRight=0;
			rectangle.moveLeft();
		}
		if(rightNumber==1){
			rectangle.countSpeedLeft=0;
			rectangle.moveRight(this.getWidth());
		}
	}
}
