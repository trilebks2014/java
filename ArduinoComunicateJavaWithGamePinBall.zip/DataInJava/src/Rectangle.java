import java.awt.Color;
import java.awt.Graphics;

class Rectangle {
	 int xPosition,yPosition,widthRect,heightRect,speedRect,countSpeedLeft,countSpeedRight;
	 public Rectangle(){
		 xPosition=0;
		 yPosition=0;
		 widthRect=70;
		 heightRect=20;
		 speedRect=50;
	 }
	 public Rectangle(int xPosition,int yPosition,int widthRect,int heightRect,int speedRect,int countSpeed){
		 this.xPosition=xPosition;
		 this.yPosition=yPosition;
		 this.widthRect=widthRect;
		 this.heightRect=heightRect;
		 this.speedRect=speedRect;
		 this.countSpeedLeft=countSpeed;
		 this.countSpeedRight=countSpeed;
	 }
	 public void paint(Graphics graphics){
		 graphics.setColor(Color.RED);
		 graphics.fillRect(xPosition, yPosition, widthRect, heightRect);
	 }
	 public void moveLeft(){
		 if(xPosition>=0)xPosition-=speedRect*(countSpeedLeft%10);
		 countSpeedLeft++;
		 
	 }
	 public void moveRight(int widthScreen){
		 if(xPosition<widthScreen-widthRect)xPosition+=speedRect*(countSpeedRight%10);
		 countSpeedRight++;
		 
	 }
	 public void crashBall(Ball ball,int HeightScreen){
		 if(ball.xPosition>xPosition-2*ball.radius&&ball.xPosition<xPosition+widthRect&&ball.yPosition>=yPosition-ball.radius*2){
			 ball.ySpeed=-ball.ySpeed;
		 }
	 }
}
