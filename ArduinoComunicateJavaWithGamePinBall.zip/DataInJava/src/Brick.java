import java.awt.Color;
import java.awt.Graphics;

public class Brick {
	int xPosition,yPosition,widthBrick,heightBrick;
	public Brick(){
		xPosition=0;
		yPosition=0;
		widthBrick= 40;
		heightBrick=10;
	}
	public Brick(int xPosition,int yPosition, int widthBrick, int heightBrick){
		this.xPosition= xPosition;
		this.yPosition= yPosition;
		this.widthBrick=widthBrick;
		this.heightBrick=heightBrick;
	}

	public void paint(Graphics graphics){
		graphics.setColor(Color.DARK_GRAY);
		graphics.fillRect(xPosition, yPosition, widthBrick, heightBrick);
	}
	public int crashBrick(Ball ball){
		 if(ball.xPosition>xPosition-2*ball.radius&&ball.xPosition<xPosition+widthBrick&&ball.yPosition-yPosition-heightBrick<=0){
			 ball.ySpeed=-ball.ySpeed;
			 return 1;
		 }
		 return 0;
	}
}
